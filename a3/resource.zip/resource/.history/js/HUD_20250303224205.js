export class HUD {
    constructor(canvas, player) {
        this.canvas = canvas;
        this.player = player;
    }

    
    
}
